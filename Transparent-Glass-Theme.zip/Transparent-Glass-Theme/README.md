## Transparent Glass
Se your background through your Discord. Dark theme is required.

- - -
BetterDiscord Download: [https://betterdiscord.net/ghdl?id=3359](https://betterdiscord.net/ghdl?id=3359)  
Powercord Install: `git clone `
- - -

## License

See the [LICENSE]() file for license rights and limitations (MIT).